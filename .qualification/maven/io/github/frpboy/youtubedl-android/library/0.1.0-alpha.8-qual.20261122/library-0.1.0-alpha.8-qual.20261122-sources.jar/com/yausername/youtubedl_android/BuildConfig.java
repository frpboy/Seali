/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.yausername.youtubedl_android;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.yausername.youtubedl_android";
  public static final String BUILD_TYPE = "release";
}
