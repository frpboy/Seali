/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.yausername.youtubedl_common;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.yausername.youtubedl_common";
  public static final String BUILD_TYPE = "release";
}
